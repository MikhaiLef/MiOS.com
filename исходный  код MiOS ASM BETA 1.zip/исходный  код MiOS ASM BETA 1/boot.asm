[org 0x7C00]
[bits 16]

start:

    xor ax, ax
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov sp, 0x7C00    


    mov ah, 0x00
    mov al, 0x03      
    int 0x10


    mov si, msg_title
    call print_string


    call print_newline


    mov si, msg_option1
    call print_string
    call print_newline


    mov si, msg_option2
    call print_string
    call print_newline


    wait_key:
        mov ah, 0x00
        int 0x16       
        cmp al, '1'
        je do_boot
        cmp al, '2'
        je do_reboot
        jmp wait_key

do_boot:

    mov ah, 0x00
    mov al, 0x03
    int 0x10


    mov si, msg_beta
    call print_string
    ; Hang
    jmp $

do_reboot:

    int 0x19

    jmp 0xFFFF:0x0000


print_string:
    lodsb               ; load next char from SI to AL
    or al, al           ; check for zero terminator
    jz .done
    mov ah, 0x0E        ; teletype output
    mov bx, 0x07        ; page 0, color attribute (ignored in text mode)
    int 0x10
    jmp print_string
.done:
    ret

print_newline:
    mov ah, 0x0E
    mov al, 13          ; carriage return
    int 0x10
    mov al, 10          ; line feed
    int 0x10
    ret


msg_title db '===MiOS Boot MGR beta===', 0
msg_option1 db '1 - boot', 0
msg_option2 db '2 - reboot', 0
msg_beta db 'The Beta test :D', 0


times 510 - ($ - $$) db 0
dw 0xAA55