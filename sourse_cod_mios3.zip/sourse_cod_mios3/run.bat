@echo off
echo Run to QEMU
echo by Mikhail , Thank You!
"C:\Program Files\qemu\qemu-system-x86_64.exe" -drive format=raw,file="MiOS.img" -monitor stdio
pause