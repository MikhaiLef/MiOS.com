[org 0x7c00]
[bits 16]

start:
    mov ax, 0x0003
    int 0x10
    mov si, msg_welcome
    call print

shell:
    mov si, msg_prompt
    call print
    call input
    
    mov si, buffer
    lodsb
    
    cmp al, 'h'
    je help_cmd
    cmp al, 'c'
    je clear_cmd
    cmp al, 'r'
    je reboot_cmd
    cmp al, 't'
    je time_cmd
    cmp al, 'e'
    je echo_cmd
    cmp al, 'i'
    je info_cmd
    
    mov si, msg_unknown
    call print
    jmp shell

help_cmd:
    mov si, msg_help
    call print
    jmp shell

info_cmd:
    mov si, msg_info
    call print
    jmp shell

clear_cmd:
    mov ax, 0x0003
    int 0x10
    jmp shell

reboot_cmd:
    mov si, msg_reboot
    call print
    mov ah, 0x00
    int 0x16
    jmp 0xffff:0x0000

time_cmd:
    mov si, msg_time
    call print
    mov ah, 0x02
    int 0x1A
    mov al, ch
    call out_hex
    mov al, ':'
    call putc
    mov al, cl
    call out_hex
    jmp shell

echo_cmd:
    mov si, buffer
    inc si
    cmp byte [si], 0
    je echo_empty
    call print
    jmp shell
    
echo_empty:
    mov si, msg_empty
    call print
    jmp shell

input:
    mov di, buffer
    xor cx, cx
in_loop:
    mov ah, 0x00
    int 0x16
    cmp al, 0x0D
    je in_done
    cmp al, 0x08
    je in_bs
    cmp al, ' '
    jb in_loop
    mov ah, 0x0E
    int 0x10
    stosb
    inc cx
    jmp in_loop
in_bs:
    cmp cx, 0
    je in_loop
    dec di
    dec cx
    mov ah, 0x0E
    mov al, 0x08
    int 0x10
    mov al, ' '
    int 0x10
    mov al, 0x08
    int 0x10
    jmp in_loop
in_done:
    mov byte [di], 0
    mov si, msg_newline
    call print
    ret

out_hex:
    push ax
    mov ah, al
    shr al, 4
    call out_nibble
    pop ax
    and al, 0x0F
    call out_nibble
    ret

out_nibble:
    add al, '0'
    cmp al, '9'
    jle .digit
    add al, 7
.digit:
    call putc
    ret

putc:
    mov ah, 0x0E
    int 0x10
    ret

print:
    lodsb
    or al, al
    jz .done
    call putc
    jmp print
.done:
    ret

%use smartalign

msg_welcome db 'MiOS', 13, 10, 'CPU: 386+ Required', 13, 10, 0
msg_prompt db 13, 10, 'MiOS_$', 0
msg_help db 13, 10, 'h help c cls reboot t time e echo info', 13, 10, 0
msg_unknown db 13, 10, '?', 0
msg_reboot db 13, 10, 'reboot...', 0
msg_time db 13, 10, 'T:', 0
msg_empty db 13, 10, '(empty)', 0
msg_newline db 13, 10, 0
msg_info db 13, 10, 'MiOS x32 , v.3.0 by Mikhail', 13, 10, 0

buffer times 32 db 0

times 510-($-$$) db 0
dw 0xAA55