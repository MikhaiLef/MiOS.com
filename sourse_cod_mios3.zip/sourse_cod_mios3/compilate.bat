@echo off
echo ========================================
echo      Compiling MiOS Bootloader
echo ========================================
echo.

nasm -v >nul 2>&1
if %errorlevel% neq 0 (
    echo ERROR: NASM not found!
    echo.
    echo Please install NASM assembler
    echo.
    pause
    exit /b 1
)

echo Compiling boot.asm...
nasm -f bin boot.asm -o boot.bin
if %errorlevel% neq 0 (
    echo ERROR: Compilation failed!
    pause
    exit /b 1
)

for %%A in (boot.bin) do echo [+] boot.bin created (%%~zA bytes)
echo.

echo Creating floppy image...
copy /Y boot.bin MiOS.img >nul
fsutil file seteof MiOS.img 1474560 >nul 2>&1

echo.
echo ========================================
echo      Build completed!
echo ========================================
echo.
echo To run: qemu-system-i386 -fda MiOS.img
echo.
pause